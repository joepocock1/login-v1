import tkinter
import customtkinter
import requests
from PIL import ImageTk, Image

customtkinter.set_appearance_mode("System")
customtkinter.set_default_color_theme("green")

app = customtkinter.CTk()
app.geometry("600x400")
app.title('JP Login')



def button_fuction():
    customtkinter.set_appearance_mode('dark')
    customtkinter.set_default_color_theme('green')

    root = customtkinter.CTk()
    root.title("JP Valorant Tracker")
    root.geometry("460x360")


    def search_stats():
        try:
            player = my_player.get().replace('','%20')
            tag = my_player_tag.get()
            print(tag)
            print(player)
            api_call = f'https://api.henrikdev.xyz/valorant/v1/mmr/eu/'+ player + '/' + tag
            player_data = requests.get(api_call).json()['data']
            Current_Rank = "Current Rank is: " + player_data['currenttierpatched']
            Last_Mmr_Change = str((player_data['mmr_change_to_last_game'])) + ' Last game'
            if player_data['mmr_change_to_last_game'] >= 0:
                Last_Mmr_Change = "Last Game: Gained +"+str((player_data['mmr_change_to_last_game'])) + " RR"
            elif player_data['mmr_change_to_last_game'] < 0:
                Last_Mmr_Change = "Last Game: Lost "+str((player_data['mmr_change_to_last_game'])) + " RR"
                
                
            Current_Elo = "Current Elo: "+ str(player_data['elo'])
            display.delete('1.0',customtkinter.END)
            display.insert('1.0',Current_Elo)
            display.insert('1.0','\n')
            display.insert('1.0',Last_Mmr_Change)
            display.insert('1.0','\n')
            display.insert('1.0',Current_Rank)
            
        except KeyError:
            error = 'please enter a valid player name and tag \n'
            error2 = 'maybe try removing any spaces\n'
            error3 = 'you dont need to use a hashtag before the tag'
            display.delete('1.0',customtkinter.END)
            display.insert('1.0',error+error2+error3)

    #main frame
    frame = customtkinter.CTkFrame(master=root)
    frame.pack(pady=10,padx=60, fill='both',expand=True)


    label = customtkinter.CTkLabel(master=frame, text="JP Tracker", font=('Calibri Bold',24), text_color='light grey')
    label.pack(pady=12,padx=10)

    my_player = customtkinter.StringVar()
    my_player= customtkinter.CTkEntry(master=frame, placeholder_text='Player Name')
    my_player.pack(pady=12,padx=10)

    my_player_tag = customtkinter.StringVar()
    my_player_tag= customtkinter.CTkEntry(master=frame, placeholder_text='Player Tag')
    my_player_tag.pack(pady=12,padx=10)

    button = customtkinter.CTkButton(master=frame, text="Search",command=search_stats)
    button.pack(pady=12,padx=10)

    display = tkinter.Text(master=frame, bg= '#77dd77',font='Calibri_Bold')
    display.pack(pady=12,padx=10)

    root.mainloop()

def login_validate():
    username = "joe"
    password = "pocock"
    if entry1.get()== username and entry2.get() == password:
        print("Login Successful")
        app.destroy()
        button_fuction()
    else:
        print("Invalid Login")

img1 = ImageTk.PhotoImage(Image.open("pattern.png"))
label1 = customtkinter.CTkLabel(master=app, image=img1)
label1.pack()

frame= customtkinter.CTkFrame(master=label1, width=320, height=360, corner_radius=15)
frame.place(relx=0.5, rely=0.5,anchor=tkinter.CENTER)

label2 = customtkinter.CTkLabel(master=frame,text="Login Page", font=("Calibri Bold",20))
label2.place(x=115,y=45)

entry1=customtkinter.CTkEntry(master=frame, width= 220,placeholder_text="Username")
entry1.place(x=50,y= 110)

entry2=customtkinter.CTkEntry(master=frame, width= 220,placeholder_text="Password", show="*")
entry2.place(x=50,y= 165)

label3 = customtkinter.CTkLabel(master=frame,text="Forgot Password?", font=("Calibri Bold",12))
label3.place(x=180,y=195)

button1= customtkinter.CTkButton(master=frame,width=220, text="Login", corner_radius=6, text_color="White",command=login_validate)
button1.place(x=50,y=240)


img2 = customtkinter.CTkImage(Image.open("google.png").resize((20,20),Image.ANTIALIAS))
img3 = customtkinter.CTkImage(Image.open("google.png").resize((20,20),Image.ANTIALIAS))


button2= customtkinter.CTkButton(master=frame, image=img2,text="Google",width=100,height=20, corner_radius=6, compound="left", text_color='Black',fg_color= "white", hover_color= "#A4A4A4")
button2.place(x=50,y=290)

button3= customtkinter.CTkButton(master=frame, image=img3,text="Facebook",width=100,height=20, corner_radius=6, compound="left", text_color='Black',fg_color= "white",hover_color= "#A4A4A4")
button3.place(x=170,y=290)

app.mainloop()